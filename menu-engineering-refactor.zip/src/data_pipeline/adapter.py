"""Adapt arbitrary menu/POS CSV columns into the canonical analysis schema."""

from __future__ import annotations

import csv
from collections.abc import Iterable, Mapping
from difflib import SequenceMatcher

import pandas as pd

from config import (
    CANONICAL_FIELDS,
    COLUMN_ALIASES,
    CORE_FIELDS,
    classify_menu_item,
    normalize_column_name,
)

NOT_AVAILABLE = "Not available"


def read_delimited_csv(file_obj,encoding: str = "utf-8-sig") -> pd.DataFrame:
    """Read bounded POS CSV files with quote-aware delimiter detection.
    Supports comma, pipe, semicolon, and tab delimiters.
    """
    # Validate the selected file encoding.
    supported_encodings = {"utf-8-sig", "cp1252"}

    if encoding not in supported_encodings:
        raise ValueError(
            "Unsupported CSV encoding. "
            "Choose UTF-8 or Windows-1252."
        )

    max_file_bytes = 200 * 1024 * 1024
    max_rows = 500_000
    max_columns = 200
    chunk_size = 25_000

    # Check file size without loading the whole file into memory.
    file_obj.seek(0, 2)
    file_size = file_obj.tell()
    file_obj.seek(0)

    if file_size == 0:
        raise ValueError("The uploaded file is empty.")

    if file_size > max_file_bytes:
        raise ValueError(
            "The uploaded CSV exceeds the 200 MB file limit."
        )

    # Read a small sample for delimiter and encoding detection.
    sample = file_obj.read(16_384)
    file_obj.seek(0)

    if isinstance(sample, bytes):
        try:
            sample_text = sample.decode(encoding)
        except UnicodeDecodeError as exc:
            raise ValueError(
                "Unable to parse the uploaded CSV. "
                f"The file cannot be decoded using {encoding}. "
                "Choose the correct file encoding."
            ) from exc
    else:
        sample_text = sample

    if not sample_text.strip():
        raise ValueError("The uploaded file is empty.")

    # CSV Sniffer understands quotation marks and escaped delimiters.
    try:
        dialect = csv.Sniffer().sniff(
            sample_text,
            delimiters=",|;\t",
        )
        detected_delimiter = dialect.delimiter
    except csv.Error as exc:
        raise ValueError(
            "Could not detect the file delimiter. "
            "Supported delimiters are comma, pipe, "
            "semicolon, and tab."
        ) from exc

    chunks: list[pd.DataFrame] = []
    total_rows = 0

    try:
        reader = pd.read_csv(
            file_obj,
            sep=detected_delimiter,
            encoding=encoding,
            chunksize=chunk_size,
            low_memory=False,
        )

        for chunk in reader:
            if len(chunk.columns) > max_columns:
                raise ValueError(
                    "The uploaded CSV has too many columns. "
                    f"Maximum supported: {max_columns}."
                )

            total_rows += len(chunk)

            if total_rows > max_rows:
                raise ValueError(
                    "The uploaded CSV has too many rows. "
                    f"Maximum supported: {max_rows:,}."
                )

            chunks.append(chunk)

    except (pd.errors.ParserError, UnicodeError) as exc:
        raise ValueError(
            "Unable to parse the uploaded CSV. "
            "Check the file format and encoding."
        ) from exc

    if not chunks:
        raise ValueError(
            "The uploaded CSV contains no data rows."
        )

    return pd.concat(
        chunks,
        ignore_index=True,
    )


# Convenience templates for common example POS export layouts.
# These are examples, not verified official company export formats.
KNOWN_MAPPING_PRESETS: dict[str, dict[str, str]] = {
    "Starbucks-style POS export": {
        "date": "transaction_date",
        "item": "product_detail",
        "category": "product_category",
        "price": "unit_price",
        "units_sold": "transaction_qty",
    },
    "Blue Bottle-style POS export": {
        "date": "order_date",
        "item": "item_name",
        "category": "menu_category",
        "price": "sales_price",
        "units_sold": "qty",
    },
    "Square/Toast-style export": {
        "date": "date",
        "item": "item",
        "category": "category",
        "price": "price",
        "unit_cost": "cost",
        "units_sold": "qty",
    },
}


def apply_known_preset(
    columns: Iterable[object],
    preset_name: str,
) -> dict[str, str | None]:
    """Apply only preset fields found in the uploaded CSV."""
    available = {str(col) for col in columns}
    preset = KNOWN_MAPPING_PRESETS.get(preset_name, {})

    return {
        field: raw_col
        for field, raw_col in preset.items()
        if raw_col in available
    }


def mapping_confidence(
    columns: Iterable[object],
    mapping: Mapping[str, str | None],
) -> dict[str, str]:
    """Show whether mappings are exact, recognized aliases, or tentative."""
    labels: dict[str, str] = {}

    for field in CANONICAL_FIELDS:
        raw = mapping.get(field)

        if not raw:
            labels[field] = "not mapped"
        elif normalize_column_name(raw) == normalize_column_name(field):
            labels[field] = "exact"
        elif normalize_column_name(raw) in {
            normalize_column_name(a)
            for a in COLUMN_ALIASES[field]
        }:
            labels[field] = "alias"
        else:
            labels[field] = "review manually"

    return labels


def detect_column_mapping(columns: Iterable[object]) -> dict[str, str | None]:
    """Detect raw-to-canonical mappings using normalized aliases and conservative fuzzy matching."""
    raw_columns = [str(col) for col in columns]
    normalized_raw = {raw: normalize_column_name(raw) for raw in raw_columns}
    mapping: dict[str, str | None] = {field: None for field in CANONICAL_FIELDS}
    used: set[str] = set()

    for field in CANONICAL_FIELDS:
        aliases = {normalize_column_name(alias) for alias in COLUMN_ALIASES[field]}
        exact = [raw for raw, norm in normalized_raw.items() if norm in aliases and raw not in used]
        if len(exact) == 1:
            mapping[field] = exact[0]
            used.add(exact[0])
            continue

        # Conservative fallback: useful for minor punctuation/wording differences,
        # but high enough to avoid surprising automatic assignments.
        scored: list[tuple[float, str]] = []
        for raw, norm in normalized_raw.items():
            if raw in used:
                continue
            score = max(SequenceMatcher(None, norm, alias).ratio() for alias in aliases)
            if score >= 0.90:
                scored.append((score, raw))
        scored.sort(reverse=True)
        if scored and (len(scored) == 1 or scored[0][0] - scored[1][0] >= 0.03):
            mapping[field] = scored[0][1]
            used.add(scored[0][1])

    return mapping


def validate_mapping(mapping: Mapping[str, str | None], available_columns: Iterable[object]) -> list[str]:
    """Return human-readable mapping errors before dataframe adaptation."""
    errors: list[str] = []
    available = {str(col) for col in available_columns}

    missing_core = [field for field in CORE_FIELDS if not mapping.get(field)]
    if missing_core:
        errors.append("Map the required fields: " + ", ".join(missing_core) + ".")

    selected = [str(raw) for raw in mapping.values() if raw]
    duplicates = sorted({raw for raw in selected if selected.count(raw) > 1})
    if duplicates:
        errors.append("Each source column can map to only one field. Reused: " + ", ".join(duplicates) + ".")

    missing_raw = [str(raw) for raw in mapping.values() if raw and str(raw) not in available]
    if missing_raw:
        errors.append("Mapped columns were not found in the CSV: " + ", ".join(missing_raw) + ".")
    return errors


def adapt_to_canonical(
    raw_df: pd.DataFrame,
    mapping: Mapping[str, str | None] | None = None,
) -> tuple[pd.DataFrame, list[str]]:
    """Rename/select raw columns into the canonical schema without doing numeric analysis."""
    if raw_df is None or raw_df.empty:
        return pd.DataFrame(
            columns=[*CANONICAL_FIELDS, "category_group"]
        ), []

    mapping = dict(mapping or detect_column_mapping(raw_df.columns))
    errors = validate_mapping(mapping, raw_df.columns)
    if errors:
        raise ValueError(" ".join(errors))

    out = pd.DataFrame(index=raw_df.index)
    for field in CANONICAL_FIELDS:
        raw_col = mapping.get(field)
        if raw_col:
            out[field] = raw_df[str(raw_col)]

    warnings: list[str] = []
    if "category" not in out:
        out["category"] = "Uncategorized"
        warnings.append("No category column was mapped. Missing categories were set to 'Uncategorized'.")
    else:
        blank = out["category"].isna() | out["category"].astype(str).str.strip().isin(["", "nan", "None"])
        if blank.any():
            out.loc[blank, "category"] = "Uncategorized"
            warnings.append(f"{int(blank.sum())} rows had no category and were set to 'Uncategorized'.")

    if "unit_cost" not in out:
        out["unit_cost"] = pd.NA
        warnings.append(
            "Unit cost was not mapped. Revenue/popularity analysis can run, but profit-based analysis needs cost data."
        )
    
    # Transaction time is optional.
    # Preserve it when available and leave it missing otherwise.
    if "transaction_time" not in out:
        out["transaction_time"] = pd.NA

    # Preserve existing canonical columns and their order.
    out = out[CANONICAL_FIELDS].copy()

    # Automatically group menu categories.
    out["category_group"] = [
        classify_menu_item(category, item)
        for category, item in zip(out["category"], out["item"])
    ]

    # Warn users when categories are not recognized.
    other_count = int((out["category_group"] == "Other").sum())

    if other_count:
        warnings.append(
            f"{other_count} rows were classified as 'Other'. "
            "Review category mappings if needed."
        )

    return out, warnings



def merge_cost_reference(
    sales_df: pd.DataFrame,
    raw_cost_df: pd.DataFrame,
    item_column: str,
    cost_column: str,
) -> tuple[pd.DataFrame, list[str]]:
    """Fill unit_cost by matching item names to a separate menu-cost CSV."""
    warnings: list[str] = []
    if item_column not in raw_cost_df.columns or cost_column not in raw_cost_df.columns:
        raise ValueError("The selected item/cost columns were not found in the cost CSV.")

    cost_df = raw_cost_df[[item_column, cost_column]].copy()
    cost_df["_item_key"] = cost_df[item_column].astype(str).str.strip().str.casefold()
    cost_df["_cost"] = pd.to_numeric(cost_df[cost_column], errors="coerce")
    cost_df = cost_df.dropna(subset=["_cost"])

    duplicate_keys = cost_df["_item_key"].duplicated(keep=False)
    if duplicate_keys.any():
        warnings.append("The cost CSV had duplicate item names; the last valid cost for each item was used.")
    cost_df = cost_df.drop_duplicates("_item_key", keep="last")

    out = sales_df.copy()
    out["_item_key"] = out["item"].astype(str).str.strip().str.casefold()
    cost_map = cost_df.set_index("_item_key")["_cost"]
    mapped = out["_item_key"].map(cost_map)
    out["unit_cost"] = out["unit_cost"].where(out["unit_cost"].notna(), mapped)
    out = out.drop(columns=["_item_key"])

    missing = int(out["unit_cost"].isna().sum())
    if missing:
        warnings.append(
            f"Cost lookup did not match {missing} sales rows. Profit-dependent features remain disabled until all rows have cost."
        )
    return out, warnings


def apply_estimated_cost_percentage(df: pd.DataFrame, cost_pct: float) -> pd.DataFrame:
    """Create an explicit scenario cost assumption as a percentage of selling price."""
    if not 0 <= cost_pct < 1:
        raise ValueError("Estimated cost percentage must be between 0% and less than 100%.")
    out = df.copy()
    prices = pd.to_numeric(out["price"], errors="coerce")
    out["unit_cost"] = prices * float(cost_pct)
    return out
